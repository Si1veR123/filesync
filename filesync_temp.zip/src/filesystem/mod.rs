pub mod zip;
pub mod upload;

use std::env::current_dir;
pub fn directory_name() -> String {
    current_dir().unwrap().file_name().unwrap().to_os_string().into_string().unwrap()
}

pub const TEMP_ZIP_LOCATION: &'static str = "filesync_temp.zip";
