pub mod zip;
pub mod upload;

pub const TEMP_ZIP_LOCATION: &'static str = "filesync_temp.zip";
