mod filesystem;
mod authenticate;

use filesystem::upload::{upload_to_drive, delete_previous_from_cloud};

use authenticate::auth::get_drive_client;
use authenticate::token_storing::delete_refresh_token;

use tokio;
use std::env::args;

fn help() {
    println!(concat!(
        "Usage:\n",
        "[COMMANDS]\n",
        "up\tUpload the local project to google drive\n",
        "down\tDownload the cloud project from google drive\n",
        "logout\tRemove google account from this device (will not remove this app from your google account)\n",
        "[OPTIONS]\n",
        "-a\tUpload/Download all files without confirmation\n"
    ));
}

#[tokio::main]
async fn main() -> Result<(), ()> {
    let command = args().nth(1);
    if command.is_none() {
        help();
        return Ok(())
    }

    match command.unwrap().as_str() {
        "up" => {
            let (client, token) = get_drive_client().await;
            upload_to_drive(&client, &token).await
        },
        "down" => {
            let (client, token) = get_drive_client().await;
        },
        "logout" => {
            let result = delete_refresh_token();
            match result {
                Ok(_) => {
                    println!("Logged out");
                },
                Err(e) => {
                    println!("{e}");
                }
            }
        }
        _ => {
            println!("Invalid argument given.");
            help();
            return Ok(());
        }
    }

    Ok(())
}
